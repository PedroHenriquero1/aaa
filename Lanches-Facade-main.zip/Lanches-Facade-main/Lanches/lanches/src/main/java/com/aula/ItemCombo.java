package com.aula;

public interface ItemCombo {

    String getNome();
    double getPreco();
}
